import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceGameFinalPhase extends PApplet {

// SpaceGame 2020 December 
// by Kevin Liu
SpaceShip s1;
ArrayList<Star> stars;
ArrayList<PowerUp> pUps;
ArrayList<Laser> lasers;
ArrayList<Rock> rocks;
ArrayList<EnemyShip> enemies;
ArrayList<EnemyLaser> elasers;
Timer rocktimer, putimer, enemytimer;
int score, pass, weaponCount, superWeapon;
boolean play;

SoundFile laser;

public void setup() {
  
  s1 = new SpaceShip(0xffFF00FF);
  stars = new ArrayList();
  pUps = new ArrayList();
  lasers = new ArrayList();
  rocks = new ArrayList();
  enemies = new ArrayList();
  elasers = new ArrayList();
  rocktimer = new Timer(PApplet.parseInt(random(500, 3000)));
  rocktimer.start();
  score = 0;
  pass = 0;
  play = false;
  putimer = new Timer(PApplet.parseInt(random(5000, 10000)));
  putimer.start();
  weaponCount = 1;
  superWeapon = 0;
  enemytimer = new Timer(PApplet.parseInt(random(5000, 7500)));
  enemytimer.start();
  laser = new SoundFile(this, "ISD-Laser4.wav");
}

public void draw() {
  noCursor();
  // Gameplay
  if (!play) {
    startScreen();
  } else {
    background(0);

    stars.add(new Star(PApplet.parseInt(random(width)), PApplet.parseInt(random(height)), 255));
    for (int i = 0; i < stars.size(); i++) {
      Star star = stars.get(i);
      star.display();
      star.move();
      if (star.reachedBottom()) {
        rocks.remove(star);
      }
    }
    if (rocktimer.isFinished()) {
      rocks.add(new Rock(PApplet.parseInt(random(width)), -50));
      rocktimer.start();
    }

    //Rocks
    for (int i = 0; i < rocks.size(); i++) {
      Rock rock = rocks.get(i);
      rock.display();
      rock.move();
      //Rock vs Ship collision
      if (s1.rockIntersection(rock)) {
        s1.health-=rock.health;
        rocks.remove(rock);
        score += rock.health;
      }
      if (rock.reachedBottom()) {
        pass++;
        rocks.remove(rock);
      }
    }

    if (enemytimer.isFinished()) {
      enemies.add(new EnemyShip(0, 80, 2000));
      enemytimer.start();
    }
    //Enemy Ship
    for (int i = 0; i<enemies.size(); i++) {
      EnemyShip enemy = enemies.get(i);
      enemy.move();
      enemy.display();
      if (s1.shipIntersect(enemy)) {
        s1.health -=50;
        enemies.remove(enemy);
        score += 50;
      }
      if (enemy.isFinished()) {
        laser.play();
        elasers.add(new EnemyLaser(color(255, 0, 0), enemy.x-35, enemy.y));
        elasers.add(new EnemyLaser(color(255, 0, 0), enemy.x+35, enemy.y));
        enemy.start();
      }
    }
    //Enemy Laser
    for (int i = elasers.size()-1; i>=0; i--) {
      EnemyLaser elaser = (EnemyLaser) elasers.get(i);
      elaser.fire();
      elaser.display();
      if (s1.enemyLaserIntersect(elaser)) {
        s1.health-=10;
        elasers.remove(elaser);
      }
      if (elaser.reachedBottom()) {
        elasers.remove(elaser);
      }
    }

    if (putimer.isFinished()) {
      pUps.add(new PowerUp(PApplet.parseInt(random(width)), -50));
      putimer.start();
    }
    //Powerups
    for (int i = 0; i < pUps.size(); i++) {
      PowerUp pu = pUps.get(i);
      pu.display();
      pu.move();
      //Rock vs Ship collision
      if (s1.puIntersection(pu)) {
        if (pu.pu == 0) {
          s1.health+=30;
        } else if (pu.pu == 1) { //Adds lasers
          weaponCount++;
        } else if (pu.pu == 2) { //Adds super weapon
          superWeapon++;
        }
        pUps.remove(pu);
      }
      if (pu.reachedBottom()) {
        rocks.remove(pUps);
      }
    }

    //Laser
    for (int i = 0; i < lasers.size(); i++) {
      Laser laser = lasers.get(i);
      laser.display();
      laser.fire();
      //Laser vs Rock Intersection
      for (int j = 0; j < rocks.size(); j++) {
        Rock rock = rocks.get(j);
        if (rock.laserIntersect(laser)) {
          rock.health-=10;
          lasers.remove(laser);
          if (rock.health<1) {
            rocks.remove(rock);
            score += 30;
          }
        }
      }
      //Laser vs EnemyShip Intersection
      for (int k = 0; k<enemies.size(); k++) {
        EnemyShip enemy = enemies.get(k);
        if (enemy.laserIntersect(laser)) {
          lasers.remove(laser);
          enemy.health-=10;
          if (enemy.health<1) {
            score+=50;
            enemies.remove(enemy);
          }
        }
      }
      if (laser.reachedTop()) {
        lasers.remove(laser);
      }
    }
    infoPanel();
    s1.display(mouseX, mouseY);

    //Gameover logic
    if (s1.health<1 || pass>5) {
      play = false;
      gameOver();
    }
  }
}

public void mousePressed() {
  laser.play();
  if (mouseButton == RIGHT && superWeapon > 0) {
    superWeapon--;
    pass = 0;
    score += 100;
    //weaponCount = 1;
    for (int i = 0; i<rocks.size(); i++) {
      Rock rock = rocks.get(i);
      rocks.remove(rock);
    }
    rocks.removeAll(rocks);
    rocktimer.start();
    for (int i = 0; i<enemies.size(); i++) {
      EnemyShip enemy = enemies.get(i);
      enemies.remove(enemy);
    }
    enemies.removeAll(enemies);
  }
  if (weaponCount == 1) {
    lasers.add(new Laser(color(255, 0, 0), s1.x, s1.y-40));
  } else if (weaponCount == 2) {
    lasers.add(new Laser(color(255, 0, 0), s1.x+35, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x-35, s1.y));
  } else if (weaponCount == 3) {
    lasers.add(new Laser(color(255, 0, 0), s1.x, s1.y-40));
    lasers.add(new Laser(color(255, 0, 0), s1.x+35, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x-35, s1.y));
  } else if (weaponCount == 4) {
    lasers.add(new Laser(color(255, 0, 0), s1.x+35, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x-35, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x+20, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x-20, s1.y));
  } else if (weaponCount == 5) {
    lasers.add(new Laser(color(255, 0, 0), s1.x+35, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x-35, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x+20, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x-20, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x, s1.y-40));
  } else if (weaponCount >= 6) {
    lasers.add(new Laser(color(255, 0, 0), s1.x+35, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x-35, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x+20, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x-20, s1.y));
    lasers.add(new Laser(color(255, 0, 0), s1.x-5, s1.y-40));
    lasers.add(new Laser(color(255, 0, 0), s1.x+5, s1.y-40));
  }
}

public void startScreen() {
  background(128);
  textAlign(CENTER);
  textSize(30);
  fill(255, 255, 0);
  text("Welcome! SpaceGame", width/2, height/2);
  text("Click to continue...", width/2, height/2+50);

  if (mousePressed) {
    play = true;
  }
}

public void infoPanel() {
  fill(128, 128);
  noStroke();
  rectMode(CORNER);
  rect(0, height-50, width, 50);
  fill(0, 255, 255);
  textSize(10);
  text("Health:" + s1.health, 50, height-20);
  text("Score:" + score, 200, height-20);
  text("Rock Pass:" + pass, 300, height-20);
  text("SuperWeapon:" + superWeapon, 400, height-20);
}

public void gameOver() {
  background(255, 0, 0);
  textAlign(CENTER);
  textSize(30);
  fill(222);
  text("Game Over!", width/2, height/2);
  text("Final Score:" + score, width/2, height/2+50);
  noLoop();
}
class EnemyLaser {
  //member variables
  int x, y, speed, rad;
  int c;
  //constructor
  EnemyLaser(int c, int x, int y) {
    this.x = x;
    this.y = y;
    this.c = c;
    speed = 5;
    rad = 1;
  }

  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }
  //member methods
  public void display() {
    fill(c);
    stroke(255, 0, 0);
    //noStroke();
    rectMode(CENTER);
    rect(x, y, rad, rad*10);
  }
  public void fire() {
    y+=speed;
  }
}
class EnemyShip {
  //member variables
  int x, y, health, speed, rad;
  boolean right;
  int savedTime;
  int totalTime;

  //constructor
  EnemyShip(int x, int y, int t) {
    this.x = x;
    this.y = x;
    health = 50;
    speed = 3;
    rad = 25;
    this.totalTime = t;
  }
  //member methods
  public void display() {
    //Second layer
    rectMode(CENTER);
    fill(0xffF6FF00);
    stroke(0);
    triangle(x, y+20, x+40, y-15, x-40, y-15);
    ellipse(x, y, 20, 80);
    rect(x+35, y-8, 5, 15);
    rect(x-35, y-8, 5, 15);
    line(x+35, y+8, x+35, y-8);
    line(x-35, y+8, x-35, y-8);
  }
  public void move() {
    x += speed;
    if(x >= width-0 || x <=0){
      speed *= -1;
      y +=50;
    }
  }
  
  public boolean laserIntersect(Laser laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if(distance < rad + laser.rad) {
      return true;
    } else {
      return false;
    }
  }
  
  public void start() {
    savedTime = millis();
  }
  
  public boolean isFinished() {
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
class Laser {
  //member variables
  int x, y, speed, rad;
  int c;
  //constructor
  Laser(int c, int x, int y) {
    this.x = x;
    this.y = y;
    this.c = c;
    speed = 5;
    rad = 1;
  }

  public boolean reachedTop() {
    if (y < 0) {
      return true;
    } else {
      return false;
    }
  }
  //member methods
  public void display() {
    fill(c);
    stroke(255, 0, 0);
    //noStroke();
    rectMode(CENTER);
    rect(x, y, rad, rad*10);
  }
  public void fire() {
    y-=speed;
  }
}
class PowerUp {
  //member variables
  int x, y, speed, pu, rad;
  String[] puInfo = {"Ammo", "Health", "Laser", "Super"};

  //constructor
  PowerUp(int x, int y) {
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(5,7));
    pu = PApplet.parseInt(random(3));
    rad = 10;
  }
  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }
  public void move() {
    y += speed;
  }

  //member methods
  public void display() {
    noStroke();
    switch(pu) {
    case 0: //Health
      fill(0xff00FF28);
      triangle(x+5, y-10, x-15, y, x+5, y+10);
      triangle(x+10, y, x-10, y-10, x-10, y+10);
      break;
    case 1: //Lasers
      fill(0xff00FACE);
      triangle(x+5, y-10, x-15, y, x+5, y+10);
      triangle(x+10, y, x-10, y-10, x-10, y+10);
      break;
    case 2: //Super Weapon
      fill(0xff8600F5);
      triangle(x+5, y-10, x-15, y, x+5, y+10);
      triangle(x+10, y, x-10, y-10, x-10, y+10);
      break;
    }
  }
}
class Rock {
  //member variables
  int x, y, health, speed, rad;
  //constructor
  Rock(int x, int y) {
    this.x = x;
    this.y = y;
    health = 30;
    speed = PApplet.parseInt(random(2, 5));
    rad = 50;
  }
 
  public boolean reachedBottom() {
    if (y > height + 50) {
      return true;
    } else {
      return false;
    }
  }
  public void move() {
    y += speed;
  }

  //member methods
  public void display() {
    //if (health>20) {
      fill(128);
      noStroke();
      rect(x, y, 50, 50);
      quad(x, y+35, x+35, y, x, y-35, x-35, y);
    //} else if (health<10) {
    //  fill(128);
    //  noStroke();
    //  rect(x, y, 25, 25);
    //  quad(x, y+20, x+20, y, x, y-20, x-20, y);
    //}
  }
   //Laser vs Rock Intersection
  public boolean laserIntersect(Laser laser){
    float distance = dist(x,y,laser.x,laser.y);
    if(distance < rad + laser.rad) {
      return true;
    } else {
      return false;
    }
  }
}
class SpaceShip {
  //member variables
  int x, y, health, rad;
  int c;

  //constructor
  SpaceShip(int c) {
    x = 0;
    y = 0;
    health = 100;
    this.c = c;
    rad = 25;
  }

  //Rock  vs. Ship Collision
  public boolean rockIntersection(Rock rock) {
    float distance = dist(x, y, rock.x, rock.y);
    if (distance < rad + rock.rad) {
      return true;
    } else {
      return false;
    }
  }
  //PowerUp vs. Ship Collision
  public boolean puIntersection(PowerUp pu) {
    float distance = dist(x, y, pu.x, pu.y);
    if (distance < rad + pu.rad) {
      return true;
    } else {
      return false;
    }
  }

  //EnemyShip vs Ship
  public boolean shipIntersect(EnemyShip enemy) {
    float distance = dist(x, y, enemy.x, enemy.y);
    if (distance < rad + enemy.rad) {
      return true;
    } else {
      return false;
    }
  }

  //EnemyLaser vs Ship
  public boolean enemyLaserIntersect(EnemyLaser elaser) {
    float distance = dist(x, y, elaser.x, elaser.y);
    if (distance < rad + elaser.rad) {
      return true;
    } else {
      return false;
    }
  }

  //member methods
  public void display(int x, int y) {
    this.x = x;
    this.y = y;
    //Second layer (Pink)
    rectMode(CENTER);
    fill(c);
    stroke(0);
    rect(x+35, y+8, 2, 15);
    rect(x-35, y+8, 2, 15);
    stroke(0xffFF00FF);
    line(x+20, y+8, x+20, y-8);
    line(x-20, y+8, x-20, y-8);
    //line(x, y-40, x, y-60);
    stroke(0);
    triangle(x, y-20, x+40, y+15, x-40, y+15);
    ellipse(x, y, 20, 80); 
    //First Layer
    fill(0, 0, 255);
    rect(x, y, 20, 50);
    fill(255, 0, 0);
    triangle(x+10, y-25, x-10, y-25, x, y-50);
    fill(0, 255, 0);
    triangle(x+10, y, x+10, y+25, x+25, y+25);
    triangle(x-10, y, x-10, y+25, x-25, y+25);
  }
}
class Star {
  //member variables
  int x, y;
  int c;
  //constructor
  Star(int x, int y, int c) {
    this.x = x;
    this.y = y;
    this.c =c;
  }
  public boolean reachedBottom() {
    if (y > height) {
      return true;
    } else {
      return false;
    }
  }
  public void move() {
    y += random(2, 10);
  }

  //member methods
  public void display() {
    fill(c);
    stroke(c);
    ellipse(x, y, 3, 3);
  }
}
// Example 10-5: Object-oriented timer
// By Daniel Shiffman

class Timer {

  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SpaceGameFinalPhase" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
